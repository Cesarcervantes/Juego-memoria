//: Playground - noun: a place where people can play

import UIKit

var numeros = 0...100

for n in numeros {
    if n >= 30 && n <= 40{
        if n % 5 == 0 && n % 2 == 0{
            print("# \(n)\t\("Viva Swift!...Bingo!!... es par!")")
        }
        else if n % 5 == 0 && n % 2 != 0{
            print("# \(n)\t\("Viva Swift!...Bingo!!... es impar!")")
        }
        else if n % 2 == 0 {
            print("# \(n)\t\("Viva Swift!...es par!")")
        }
        else if n % 2 != 0{
            print("# \(n)\t\("Viva Swift!...es impar!")")
        }
    }
    else if n % 5 == 0 && n % 2 == 0{
        print("# \(n)\t\("Bingo!!... es par!")")
    }
    else if n % 5 == 0 && n % 2 != 0{
        print("# \(n)\t\("Bingo!!... es impar!")")
    }
    else if n % 2 == 0 {
        print("# \(n)\t\("es par!")")
    }
    else if n % 2 != 0{
        print("# \(n)\t\("es impar!")")
    }
}

